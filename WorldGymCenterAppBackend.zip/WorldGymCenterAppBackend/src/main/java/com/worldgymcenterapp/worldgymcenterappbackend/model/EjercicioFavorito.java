package com.worldgymcenterapp.worldgymcenterappbackend.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ejerciciosfav")
@IdClass(EjercicioFavoritoId.class)
public class EjercicioFavorito {

    @Id
    @Column(name = "dni")
    private String dni;

    @Id
    @Column(name = "ejercicio_id")
    private int ejercicioId;

    @Column(name = "fecha_agregado")
    private LocalDateTime fechaAgregado;

    @Column(name = "musculo")
    private String musculo;

    // constructores
    public EjercicioFavorito() {}

    public EjercicioFavorito(String dni, int ejercicioId, String musculo) {
        this.dni = dni;
        this.ejercicioId = ejercicioId;
        this.musculo = musculo;
        this.fechaAgregado = LocalDateTime.now();
    }

    // Getters y Setters
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEjercicioId() {
        return ejercicioId;
    }

    public void setEjercicioId(int ejercicioId) {
        this.ejercicioId = ejercicioId;
    }

    public LocalDateTime getFechaAgregado() {
        return fechaAgregado;
    }

    public void setFechaAgregado(LocalDateTime fechaAgregado) {
        this.fechaAgregado = fechaAgregado;
    }

    public String getMusculo() {
        return musculo;
    }

    public void setMusculo(String musculo) {
        this.musculo = musculo;
    }
}