package com.worldgymcenterapp.worldgymcenterappbackend.service;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Calendario;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.CalendarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;

import java.util.List;
import java.util.Optional;

@Service
public class CalendarioService {

    @Autowired
    private CalendarioRepository calendarioRepository;

    public List<Calendario> getAllCalendarios() {
        return calendarioRepository.findAll();
    }

    public Optional<Calendario> getCalendarioById(Long id) {
        return calendarioRepository.findById(id);
    }

    public Calendario createCalendario(Calendario calendario) {
        return calendarioRepository.save(calendario);
    }

    public Calendario updateCalendario(Long id, Calendario calendarioDetails) {
        Calendario calendario = calendarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Calendario no encontrado con id " + id));

        calendario.setTitulo(calendarioDetails.getTitulo());
        calendario.setDescripcion(calendarioDetails.getDescripcion());
        calendario.setTipo(calendarioDetails.getTipo());
        calendario.setFecha(calendarioDetails.getFecha());
        calendario.setDuracion(calendarioDetails.getDuracion());

        return calendarioRepository.save(calendario);
    }

    public void deleteCalendario(Long id) {
        Calendario calendario = calendarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Calendario no encontrado con id " + id));
        calendarioRepository.delete(calendario);
    }


    public List<Calendario> getEventosByFecha(LocalDate fecha) {
        return calendarioRepository.findByFecha(fecha);
    }


    public List<Calendario> getEventosByFechaRango(LocalDateTime startDate, LocalDateTime endDate) {
        return calendarioRepository.findByFechaRango(startDate, endDate);
    }
    public Calendario agregarEvento(Calendario calendario) {
        return calendarioRepository.save(calendario);
    }

    // metodo para eliminar un evento por id
    public boolean eliminarEvento(Long id) {
        if (calendarioRepository.existsById(id)) {
            calendarioRepository.deleteById(id);
            return true;
        } else {
            return false;
        }
    }


    // metodo en el servicio para actualizar un evento
    public Calendario actualizarEvento(Long id, Calendario calendarioDetails) {
        Optional<Calendario> optionalCalendario = calendarioRepository.findById(id);

        if (optionalCalendario.isPresent()) {
            Calendario calendario = optionalCalendario.get();

            // actualizar solo los campos que se han recibido en el request
            if (calendarioDetails.getTitulo() != null) {
                calendario.setTitulo(calendarioDetails.getTitulo());
            }
            if (calendarioDetails.getDescripcion() != null) {
                calendario.setDescripcion(calendarioDetails.getDescripcion());
            }
            if (calendarioDetails.getTipo() != null) {
                calendario.setTipo(calendarioDetails.getTipo());
            }
            if (calendarioDetails.getFecha() != null) {
                calendario.setFecha(calendarioDetails.getFecha());
            }
            if (calendarioDetails.getDuracion() != null) {
                calendario.setDuracion(calendarioDetails.getDuracion());
            }
            if (calendarioDetails.getUrl() != null) {
                calendario.setUrl(calendarioDetails.getUrl());
            }

            // guardar el evento actualizado en la base de datos
            return calendarioRepository.save(calendario);
        } else {
            return null;
        }
    }



}
