package com.worldgymcenterapp.worldgymcenterappbackend.repository;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Notificacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificacionRepository extends JpaRepository<Notificacion, Integer> {

    // obtener todas las notificaciones disponibles
    List<Notificacion> findAll();

    // de mas reciente a mas antigua, como es autoincrement pues el mayor id es la reciente:
    List<Notificacion> findAllByOrderByIdDesc();
}
