package com.worldgymcenterapp.worldgymcenterappbackend.service;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.EjercicioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EjercicioService {

    @Autowired
    private EjercicioRepository ejercicioRepository;

    // obtener todos los ejercicios
    public List<Ejercicio> obtenerTodos() {
        return ejercicioRepository.findAll(); // Esto obtiene todos los ejercicios sin ningún filtro
    }

    // obtener ejercicio por id
    public Optional<Ejercicio> obtenerPorId(int id) {
        return ejercicioRepository.findById(id);
    }

    // obtener ejercicios por músculo
    public List<Ejercicio> obtenerPorMusculo(String musculo) {
        return ejercicioRepository.findByMusculo(musculo);
    }

    // crear un nuevo ejercicio
    public Ejercicio crearEjercicio(Ejercicio ejercicio) {
        return ejercicioRepository.save(ejercicio);
    }

    // actualizar ejercicio
    public Ejercicio actualizarEjercicio(int id, Ejercicio ejercicioActualizado) {
        if (ejercicioRepository.existsById(id)) {
            ejercicioActualizado.setId(id);
            return ejercicioRepository.save(ejercicioActualizado);
        }
        return null;
    }

    // eliminar ejercicio
    public void eliminarEjercicio(int id) {
        ejercicioRepository.deleteById(id);
    }
}
