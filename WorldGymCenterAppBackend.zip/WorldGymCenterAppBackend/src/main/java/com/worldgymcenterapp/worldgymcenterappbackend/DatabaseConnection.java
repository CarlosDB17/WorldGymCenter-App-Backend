package com.worldgymcenterapp.worldgymcenterappbackend;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // URL de conexión con MySQL especificando el servidor y el timezone
   // private static final String URL = "jdbc:mysql://localhost:3306/world_gym_center_app_db?serverTimezone=UTC";
    private static final String URL = "jdbc:mysql://87.218.236.11:3306/world_gym_center_app_db?serverTimezone=UTC";

    private static final String USER = "remote_user";  // Usuario de la base de datos
    private static final String PASSWORD = "root";  // Contraseña del usuario


    public static Connection connect() throws SQLException {
        try {
            // intentar obtener una conexión a la base de datos
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión exitosa a la base de datos.");
            return connection;
        } catch (SQLException e) {
            // ii ocurre un error lanza una excepción con el mensaje correspondiente
            System.err.println("Error al intentar conectar con la base de datos.");
            throw new SQLException("Error de conexión: " + e.getMessage());
        }
    }
}


