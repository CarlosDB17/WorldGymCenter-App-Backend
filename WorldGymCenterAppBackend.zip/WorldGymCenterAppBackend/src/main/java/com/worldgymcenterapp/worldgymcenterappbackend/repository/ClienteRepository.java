// interfaz del repositorio para interactuar con la base de datos en relación con la entidad Cliente
package com.worldgymcenterapp.worldgymcenterappbackend.repository;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

// jparepository permite realizar operaciones básicas y personalizadas para la entidad cliente
public interface ClienteRepository extends JpaRepository<Cliente, String> {

    // verifica si un email ya está registrado
    boolean existsByEmail(String email);

    // verifica si un teléfono ya está registrado
    boolean existsByTelefono(String telefono);

    // método para encontrar un cliente por su email
    Cliente findByEmail(String email);

    // método para encontrar un cliente por su teléfono
    Optional<Cliente> findByTelefono(String telefono);

    // método para buscar clientes por apellido (contiene un texto específico)
    List<Cliente> findByApellidosContaining(String apellidos);

    // método para buscar clientes por nombre (contiene un texto específico)
    List<Cliente> findByNombreContaining(String nombre);

    // método para encontrar clientes cuya cuota esté atrasada (fecha de cuota antes de una fecha dada)
    List<Cliente> findByFechaCuotaBefore(LocalDate fecha);

    // método para buscar un cliente por su dni
    Optional<Cliente> findByDni(String dni);

    // método para buscar clientes cuyo nombre contiene un texto específico (ignorando mayúsculas/minúsculas)
    List<Cliente> findByNombreContainingIgnoreCase(String nombre);

    // método para buscar un cliente por su email (ignorando mayúsculas/minúsculas)
    Optional<Cliente> findByEmailIgnoreCase(String email);

    // método para buscar un cliente por su fecha de nacimiento
    List<Cliente> findByFechaNacimiento(LocalDate fechaNacimiento);

    // método para buscar clientes que tienen una fecha de cuota específica
    List<Cliente> findByFechaCuota(LocalDate fechaCuota);

    // ordenar clientes por nombre en orden ascendente
    List<Cliente> findAllByOrderByNombreAsc();

    // ordenar clientes por nombre en orden descendente
    List<Cliente> findAllByOrderByNombreDesc();

    // ordenar clientes por apellidos en orden ascendente
    List<Cliente> findAllByOrderByApellidosAsc();

    // ordenar clientes por apellidos en orden descendente
    List<Cliente> findAllByOrderByApellidosDesc();

    // ordenar clientes por fecha de cuota en orden ascendente
    List<Cliente> findAllByOrderByFechaCuotaAsc();

    // ordenar clientes por fecha de cuota en orden descendente
    List<Cliente> findAllByOrderByFechaCuotaDesc();

    // buscar clientes cuyo vencimiento de cuota esté entre dos fechas
    List<Cliente> findByFechaCuotaBetween(LocalDate inicio, LocalDate fin);

}
