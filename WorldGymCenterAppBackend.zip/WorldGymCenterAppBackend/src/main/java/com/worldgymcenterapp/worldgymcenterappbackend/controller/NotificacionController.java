package com.worldgymcenterapp.worldgymcenterappbackend.controller;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Notificacion;
import com.worldgymcenterapp.worldgymcenterappbackend.service.NotificacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notificaciones")
public class NotificacionController {

    @Autowired
    private NotificacionService notificacionService;



    // obtener todas las notificaciones disponibles en la base de datos
    @GetMapping
    public List<Notificacion> obtenerTodasLasNotificaciones() {
        return notificacionService.obtenerTodasLasNotificaciones();
    }

    // crear una nueva notificación
    @PostMapping
    public Notificacion crearNotificacion(@RequestBody Notificacion notificacion) {
        return notificacionService.crearNotificacion(notificacion);
    }

    //notificaciones ordenadas mas reciente
    @GetMapping("/ordenadas")
    public List<Notificacion> obtenerNotificacionesOrdenadas() {
        return notificacionService.obtenerNotificacionesOrdenadas();
    }





}
