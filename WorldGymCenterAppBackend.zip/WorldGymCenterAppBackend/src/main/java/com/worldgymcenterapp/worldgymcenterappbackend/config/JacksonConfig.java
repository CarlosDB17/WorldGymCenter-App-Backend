// paquete que contiene la configuracion de jackson para el backend de la aplicacion WorldGymCenter
package com.worldgymcenterapp.worldgymcenterappbackend.config;

// importacion de las librerias necesarias para trabajar con jackson y fechas java 8
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// configuracion de spring para personalizar el comportamiento de jackson
@Configuration
public class JacksonConfig {

    // metodo que crea y configura un ObjectMapper, utilizado para convertir entre objetos java y json
    @Bean
    public ObjectMapper objectMapper() {
        // crear una nueva instancia de ObjectMapper
        ObjectMapper objectMapper = new ObjectMapper();

        // registra el modulo JavaTimeModule para poder manejar correctamente los tipos de fecha como LocalDate
        objectMapper.registerModule(new JavaTimeModule());

        // devolver el ObjectMapper configurado
        return objectMapper;
    }
}
