package com.worldgymcenterapp.worldgymcenterappbackend.service;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Notificacion;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.NotificacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificacionService {

    @Autowired
    private NotificacionRepository notificacionRepository;

    // obtener todas las notificaciones
    public List<Notificacion> obtenerTodasLasNotificaciones() {
        return notificacionRepository.findAll();
    }

    // crear una nueva notificación
    public Notificacion crearNotificacion(Notificacion notificacion) {
        return notificacionRepository.save(notificacion);
    }

    // usar metodo ordenar notis
    public List<Notificacion> obtenerNotificacionesOrdenadas() {
        return notificacionRepository.findAllByOrderByIdDesc();
    }


}
