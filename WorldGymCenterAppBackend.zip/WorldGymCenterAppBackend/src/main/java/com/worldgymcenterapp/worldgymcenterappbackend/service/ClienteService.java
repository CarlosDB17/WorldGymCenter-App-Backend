package com.worldgymcenterapp.worldgymcenterappbackend.service;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Cliente;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.ClienteRepository;
import com.worldgymcenterapp.worldgymcenterappbackend.util.PasswordGenerator;
import com.worldgymcenterapp.worldgymcenterappbackend.util.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private EmailService emailService;



    // crear un nuevo cliente
    public Cliente guardarCliente(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    // obtener cliente por dni
    public Optional<Cliente> obtenerClientePorDni(String dni) {
        return clienteRepository.findById(dni);
    }

    // obtener dni del cliente con el email
    public String obtenerDniPorEmail(String email) {
        Cliente cliente = clienteRepository.findByEmail(email);
        return (cliente != null) ? cliente.getDni() : null;
    }

    public Cliente obtenerClientePorEmailYContrasena(String email, String contrasena) {
        Cliente cliente = clienteRepository.findByEmail(email);
        if (cliente != null && PasswordUtil.verificar(contrasena, cliente.getContrasena())) {
            return cliente;
        }
        return null;
    }




    // Buscar cliente por email
    public Cliente obtenerClientePorEmail(String email) {
        return clienteRepository.findByEmail(email);
    }

    // Buscar clientes por apellido
    public List<Cliente> obtenerClientesPorApellido(String apellidos) {
        return clienteRepository.findByApellidosContaining(apellidos);
    }

    // Buscar clientes con cuota vencida
    public List<Cliente> obtenerClientesConCuotaVencida(LocalDate fecha) {
        return clienteRepository.findByFechaCuotaBefore(fecha);
    }

    // Buscar clientes por fecha de nacimiento
    public List<Cliente> obtenerClientesPorFechaNacimiento(LocalDate fechaNacimiento) {
        return clienteRepository.findByFechaNacimiento(fechaNacimiento);
    }



    //  métodos contraseña
    public boolean cambiarContrasenaAutenticado(String dni, String contrasenaActual, String nuevaContrasena) {
        Optional<Cliente> clienteOpt = clienteRepository.findById(dni);
        if (clienteOpt.isPresent()) {
            Cliente cliente = clienteOpt.get();
            if (PasswordUtil.esContrasenaCorrecta(contrasenaActual, cliente.getContrasena())) {
                cliente.setContrasena(PasswordUtil.encriptar(nuevaContrasena));
                clienteRepository.save(cliente);
                String mensaje = """
    <html>
    <body>
        <h2 style="color: #003366;">Hola, %s</h2>
        <p><strong>Su contraseña ha sido cambiada.</strong></p>
        <p>Si no fue usted la persona que solicitó esto, le recomendamos cambiarla cuanto antes.</p>
        <br>
        <p style="color: #666;">Atentamente,<br><strong>Equipo de World Gym Center</strong></p>
    </body>
    </html>
""".formatted(cliente.getNombre());

                emailService.enviarCorreo(cliente.getEmail(), "Contraseña cambiada", mensaje);
                return true;
            }
        }
        return false;
    }

    public boolean recuperarContrasena(String dni, String email) {
        Optional<Cliente> clienteOpt = clienteRepository.findById(dni);

        if (clienteOpt.isEmpty()) {
            return false; // DNI no encontrado
        }

        Cliente cliente = clienteOpt.get();

        if (!cliente.getEmail().equalsIgnoreCase(email)) {
            return false; // El email no coincide
        }

        // Generar nueva contraseña
        String nuevaContrasena = PasswordGenerator.generarContrasena();
        cliente.setContrasena(PasswordUtil.encriptar(nuevaContrasena));
        clienteRepository.save(cliente);

        String asunto = "Recuperación de contraseña - World Gym Center";
        String mensaje = """
        <html>
        <body>
            <h2 style="color: #003366;">Hola, %s</h2>
            <p>Hemos recibido una solicitud para restablecer su contraseña.</p>
            <p><strong>Su nueva contraseña es:</strong> <span style="font-size: 18px; font-weight: bold;">%s</span></p>
            <p>Por seguridad, le recomendamos cambiarla después de iniciar sesión.</p>
            <br>
            <p>Si usted no solicitó este cambio, por favor ignore este mensaje.</p>
            <p style="color: #666;">Atentamente,<br><strong>Equipo de World Gym Center</strong></p>
        </body>
        </html>
    """.formatted(cliente.getNombre(), nuevaContrasena);

        emailService.enviarCorreo(cliente.getEmail(), asunto, mensaje);

        return true;
    }




    public boolean autenticarUsuario(String email, String contrasena) {
        Cliente cliente = clienteRepository.findByEmail(email);

        // Verifica si el usuario existe y la contraseña encriptada es correcta
        return cliente != null && PasswordUtil.verificar(contrasena, cliente.getContrasena());
    }

}
