package com.worldgymcenterapp.worldgymcenterappbackend.service;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import com.worldgymcenterapp.worldgymcenterappbackend.model.EjercicioFavorito;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.EjercicioFavoritoRepository;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.EjercicioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EjercicioFavoritoService {

    @Autowired
    private EjercicioFavoritoRepository ejercicioFavoritoRepository;

    @Autowired
    private EjercicioRepository ejercicioRepository;

    // añadir un ejercicio a favoritos
    @Transactional
    public EjercicioFavorito agregarFavorito(String dni, int ejercicioId) {
        // primero verificamos que el ejercicio exista
        Ejercicio ejercicio = ejercicioRepository.findById(ejercicioId)
                .orElseThrow(() -> new RuntimeException("Ejercicio no encontrado"));

        // verificamos que no esté ya en favoritos
        if (ejercicioFavoritoRepository.existsByDniAndEjercicioId(dni, ejercicioId)) {
            throw new RuntimeException("El ejercicio ya está en favoritos");
        }

        // creamos el objeto de favorito
        EjercicioFavorito favorito = new EjercicioFavorito(dni, ejercicioId, ejercicio.getMusculo());
        return ejercicioFavoritoRepository.save(favorito);
    }

    // obtener ejercicios favoritos de un usuario
    public List<Ejercicio> obtenerFavoritos(String dni) {
        return ejercicioFavoritoRepository.findFavoriteExercisesByDni(dni);
    }

    // eliminar un ejercicio de favoritos
    @Transactional
    public void eliminarFavorito(String dni, int ejercicioId) {
        ejercicioFavoritoRepository.deleteByDniAndEjercicioId(dni, ejercicioId);
    }

    public boolean esFavorito(String dni, int ejercicioId) {
        return ejercicioFavoritoRepository.existsByDniAndEjercicioId(dni, ejercicioId);
    }

}