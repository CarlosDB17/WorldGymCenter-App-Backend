package com.worldgymcenterapp.worldgymcenterappbackend.controller;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import com.worldgymcenterapp.worldgymcenterappbackend.service.EjercicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ejercicios")
public class EjercicioController {

    @Autowired
    private EjercicioService ejercicioService;

    // Obtener todos los ejercicios
    @GetMapping
    public List<Ejercicio> obtenerTodos() {
        return ejercicioService.obtenerTodos(); // Llama para obtener todos los ejercicios
    }

    // Obtener ejercicio por id
    @GetMapping("/{id}")
    public ResponseEntity<Ejercicio> obtenerPorId(@PathVariable int id) {
        return ejercicioService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Obtener ejercicios por músculo
    @GetMapping("/musculo/{musculo}")
    public List<Ejercicio> obtenerPorMusculo(@PathVariable String musculo) {
        return ejercicioService.obtenerPorMusculo(musculo);
    }

    // Crear un nuevo ejercicio
    @PostMapping
    public ResponseEntity<Ejercicio> crearEjercicio(@RequestBody Ejercicio ejercicio) {
        Ejercicio ejercicioCreado = ejercicioService.crearEjercicio(ejercicio);
        return ResponseEntity.status(201).body(ejercicioCreado);
    }

    // Actualizar ejercicio
    @PutMapping("/{id}")
    public ResponseEntity<Ejercicio> actualizarEjercicio(@PathVariable int id, @RequestBody Ejercicio ejercicio) {
        Ejercicio ejercicioActualizado = ejercicioService.actualizarEjercicio(id, ejercicio);
        return ejercicioActualizado != null ? ResponseEntity.ok(ejercicioActualizado) : ResponseEntity.notFound().build();
    }

    // Eliminar ejercicio
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEjercicio(@PathVariable int id) {
        ejercicioService.eliminarEjercicio(id);
        return ResponseEntity.noContent().build();
    }
}
