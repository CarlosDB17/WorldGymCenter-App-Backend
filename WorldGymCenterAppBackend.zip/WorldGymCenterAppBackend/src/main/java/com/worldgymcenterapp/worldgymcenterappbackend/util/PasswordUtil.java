// clase usada para manejar la encriptación de contraseñas usando BCrypt
package com.worldgymcenterapp.worldgymcenterappbackend.util;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public final class PasswordUtil {

    // se crea un objeto passwordEncoder con un factor de fuerza de 10
    private static final PasswordEncoder passwordEncoder = new BCryptPasswordEncoder(10); // Factor de fuerza 10

    // constructor privado para evitar la instanciación de esta clase utilitaria
    private PasswordUtil() {
        throw new UnsupportedOperationException("Esta es una clase de utilidad y no debe ser instanciada.");
    }

    // metodo estático para encriptar una contraseña
    public static String encriptar(String password) {
        return passwordEncoder.encode(password); // devuelve la contraseña encriptada
    }

    // metodo estático para verificar si una contraseña en texto plano coincide con una contraseña encriptada
    public static boolean verificar(String passwordPlano, String passwordEncriptada) {
        return passwordEncoder.matches(passwordPlano, passwordEncriptada); // compara las contraseñas
    }

    // metodo que verifica si la contraseña actual es correcta comparándola con la almacenada
    public static boolean esContrasenaCorrecta(String contrasenaActual, String contrasenaAlmacenada) {
        return verificar(contrasenaActual, contrasenaAlmacenada); // llama al método verificar
    }
}
