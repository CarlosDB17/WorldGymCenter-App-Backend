package com.worldgymcenterapp.worldgymcenterappbackend.repository;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Calendario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface CalendarioRepository extends JpaRepository<Calendario, Long> {

    // método para buscar eventos en una fecha exacta (solo la parte de la fecha, sin la hora)
    @Query("SELECT c FROM Calendario c WHERE DATE(c.fecha) = DATE(:fecha)")
    List<Calendario> findByFecha(@Param("fecha") LocalDate fecha);


    // método para buscar eventos en un rango de fechas
    @Query("SELECT c FROM Calendario c WHERE c.fecha BETWEEN :startDate AND :endDate")
    List<Calendario> findByFechaRango(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);



}
