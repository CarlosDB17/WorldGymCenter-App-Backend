package com.worldgymcenterapp.worldgymcenterappbackend.controller;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import com.worldgymcenterapp.worldgymcenterappbackend.service.EjercicioFavoritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/favoritos")
public class EjercicioFavoritoController {

    @Autowired
    private EjercicioFavoritoService ejercicioFavoritoService;

    // añadir ejercicio a favoritos
    @PostMapping("/agregar/{dni}/{ejercicioId}")
    public ResponseEntity<?> agregarFavorito(
            @PathVariable String dni,
            @PathVariable int ejercicioId
    ) {
        try {
            ejercicioFavoritoService.agregarFavorito(dni, ejercicioId);
            return ResponseEntity.ok("Ejercicio con ID " + ejercicioId + " agregado a favoritos correctamente.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // obtener ejercicios favoritos de un usuario
    @GetMapping("/{dni}")
    public List<Ejercicio> obtenerFavoritos(@PathVariable String dni) {
        return ejercicioFavoritoService.obtenerFavoritos(dni);
    }

    // eliminar ejercicio de favoritos
    @DeleteMapping("/eliminar/{dni}/{ejercicioId}")
    public ResponseEntity<?> eliminarFavorito(
            @PathVariable String dni,
            @PathVariable int ejercicioId
    ) {
        ejercicioFavoritoService.eliminarFavorito(dni, ejercicioId);
        return ResponseEntity.ok("Ejercicio con ID " + ejercicioId + " eliminado de favoritos correctamente.");
    }

//ejercicios fav por dni
    @GetMapping("/es-favorito/{dni}/{ejercicioId}")
    public ResponseEntity<Boolean> esFavorito(
            @PathVariable String dni,
            @PathVariable int ejercicioId
    ) {
        return ResponseEntity.ok(ejercicioFavoritoService.esFavorito(dni, ejercicioId));
    }
}
