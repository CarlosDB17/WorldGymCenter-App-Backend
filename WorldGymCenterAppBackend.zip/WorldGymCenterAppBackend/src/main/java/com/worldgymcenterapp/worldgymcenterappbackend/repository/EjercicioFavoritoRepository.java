package com.worldgymcenterapp.worldgymcenterappbackend.repository;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import com.worldgymcenterapp.worldgymcenterappbackend.model.EjercicioFavorito;
import com.worldgymcenterapp.worldgymcenterappbackend.model.EjercicioFavoritoId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface EjercicioFavoritoRepository extends JpaRepository<EjercicioFavorito, EjercicioFavoritoId> {

    // obtener ejercicios favoritos de un usuario mediante su dni
    @Query("SELECT e FROM Ejercicio e JOIN EjercicioFavorito ef ON e.id = ef.ejercicioId WHERE ef.dni = :dni")
    List<Ejercicio> findFavoriteExercisesByDni(@Param("dni") String dni);

    // verificar si un ejercicio es favorito de un usuario (usando dni y id del ejercicio)
    boolean existsByDniAndEjercicioId(String dni, int ejercicioId);

    // eliminar un ejercicio de favoritos de un usuario mediante su dni y el id del ejercicio
    void deleteByDniAndEjercicioId(String dni, int ejercicioId);
}