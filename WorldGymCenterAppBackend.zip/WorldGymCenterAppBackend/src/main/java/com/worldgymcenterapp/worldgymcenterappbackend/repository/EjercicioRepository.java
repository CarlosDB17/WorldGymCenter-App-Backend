package com.worldgymcenterapp.worldgymcenterappbackend.repository;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Ejercicio;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EjercicioRepository extends JpaRepository<Ejercicio, Integer> {

    // metodo para obtener ejercicios por músculo
    List<Ejercicio> findByMusculo(String musculo);
}
