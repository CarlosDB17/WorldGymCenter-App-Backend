package com.worldgymcenterapp.worldgymcenterappbackend;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WorldGymCenterAppBackendApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(WorldGymCenterAppBackendApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		System.out.println("World Gym Center App Backend ejecutándose.");
	}
}
