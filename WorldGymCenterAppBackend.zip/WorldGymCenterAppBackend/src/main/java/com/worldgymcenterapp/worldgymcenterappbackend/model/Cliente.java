package com.worldgymcenterapp.worldgymcenterappbackend.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.annotation.Nullable;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;

@Entity
@Table(name = "clientes")
public class Cliente {

    @Id
    private String dni;
    private String nombre;
    private String apellidos;
    private String email;
    private String contrasena;
    private String telefono;

    @JsonFormat(pattern = "dd-MM-yyyy")  // esto asegura que se serialice correctamente
    @DateTimeFormat(pattern = "d-M-yyyy")
    private LocalDate fechaNacimiento;

    @JsonFormat(pattern = "dd-MM-yyyy")  // esto asegura que se serialice correctamente
    @DateTimeFormat(pattern = "d-M-yyyy")
    @Nullable
    private LocalDate fechaCuota;


    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public LocalDate getFechaCuota() {
        return fechaCuota;
    }

    public void setFechaCuota(LocalDate fechaCuota) {
        this.fechaCuota = fechaCuota;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
