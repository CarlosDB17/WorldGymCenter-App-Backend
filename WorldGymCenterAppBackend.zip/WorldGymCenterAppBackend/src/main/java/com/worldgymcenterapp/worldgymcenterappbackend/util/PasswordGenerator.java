// clase utilitaria para generar contraseñas aleatorias
package com.worldgymcenterapp.worldgymcenterappbackend.util;

import java.security.SecureRandom;

public class PasswordGenerator {

    // se utiliza SecureRandom para generar números aleatorios de manera más segura
    private static final SecureRandom random = new SecureRandom();

    // longitud de la contraseña que se va a generar
    private static final int PASSWORD_LENGTH = 6;

    // metodo estatico para generar una contraseña aleatoria
    public static String generarContrasena() {
        // se crea un StringBuilder para construir la contraseña
        StringBuilder password = new StringBuilder(PASSWORD_LENGTH);

        // bucle que genera una contraseña de longitud PASSWORD_LENGTH
        for (int i = 0; i < PASSWORD_LENGTH; i++) {
            // se agrega un número aleatorio entre 0 y 9 a la contraseña
            password.append(random.nextInt(10)); // números del 0 al 9
        }

        // se retorna la contraseña generada como un String
        return password.toString();
    }
}
