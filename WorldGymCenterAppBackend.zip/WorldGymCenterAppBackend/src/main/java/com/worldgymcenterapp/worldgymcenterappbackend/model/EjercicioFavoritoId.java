package com.worldgymcenterapp.worldgymcenterappbackend.model;

import java.io.Serializable;
import java.util.Objects;

public class EjercicioFavoritoId implements Serializable {
    private String dni;
    private int ejercicioId;


    public EjercicioFavoritoId() {}

    // constructor
    public EjercicioFavoritoId(String dni, int ejercicioId) {
        this.dni = dni;
        this.ejercicioId = ejercicioId;
    }

    // getter y setters
    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getEjercicioId() {
        return ejercicioId;
    }

    public void setEjercicioId(int ejercicioId) {
        this.ejercicioId = ejercicioId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EjercicioFavoritoId that = (EjercicioFavoritoId) o;
        return ejercicioId == that.ejercicioId && Objects.equals(dni, that.dni);
    }

    @Override
    public int hashCode() {
        return Objects.hash(dni, ejercicioId);
    }
}