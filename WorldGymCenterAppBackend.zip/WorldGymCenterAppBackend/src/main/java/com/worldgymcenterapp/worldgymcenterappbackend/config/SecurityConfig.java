// paquete que contiene la configuracion de seguridad para el backend de la aplicacion WorldGymCenter
package com.worldgymcenterapp.worldgymcenterappbackend.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

// configuracion de seguridad para la aplicacion
@Configuration
public class SecurityConfig {

    // metodo que configura las reglas de seguridad para la aplicacion
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // deshabilita la proteccion CSRF (Cross-Site Request Forgery)
                .csrf(csrf -> csrf.disable())

                // configura las reglas de autorizacion para las peticiones HTTP
                .authorizeHttpRequests(auth -> auth
                        // protege solo los endpoints relacionados con autenticacion
                        .requestMatchers("/auth/**").authenticated()
                        // permite acceso libre al resto de la API
                        .anyRequest().permitAll()
                )

                // deshabilita el formulario de inicio de sesion
                .formLogin(login -> login.disable())

                // deshabilita la autenticacion basica HTTP
                .httpBasic(basic -> basic.disable());

        // devuelve la configuracion de seguridad construida
        return http.build();
    }
}
