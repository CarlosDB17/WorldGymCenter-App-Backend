package com.worldgymcenterapp.worldgymcenterappbackend.controller;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Cliente;
import com.worldgymcenterapp.worldgymcenterappbackend.repository.ClienteRepository;
import com.worldgymcenterapp.worldgymcenterappbackend.service.ClienteService;
import com.worldgymcenterapp.worldgymcenterappbackend.service.EmailService;
import com.worldgymcenterapp.worldgymcenterappbackend.util.PasswordUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
@RequestMapping("/clientes")
public class ClienteController {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteService clienteService;

    @Autowired
    private EmailService emailService;

    // obtener todos los clientes
    @GetMapping
    public List<Cliente> obtenerClientes() {
        return clienteRepository.findAll();
    }

    @PostMapping
    public ResponseEntity<Map<String, String>> crearCliente(@RequestBody Cliente cliente) {
        if (clienteRepository.existsById(cliente.getDni())) {
            return new ResponseEntity<>(Map.of("error", "El DNI ya está registrado."), HttpStatus.CONFLICT);
        }

        if (clienteRepository.findByEmailIgnoreCase(cliente.getEmail()).isPresent()) {
            return new ResponseEntity<>(Map.of("error", "El correo electrónico ya está registrado."), HttpStatus.CONFLICT);
        }

        if (clienteRepository.findByTelefono(cliente.getTelefono()).isPresent()) {
            return new ResponseEntity<>(Map.of("error", "El teléfono ya está registrado."), HttpStatus.CONFLICT);
        }

        if (!cliente.getEmail().matches("[^@\\s]+@[^@\\s]+\\.[^@\\s]+")) {
            return new ResponseEntity<>(Map.of("error", "El email proporcionado no es válido."), HttpStatus.BAD_REQUEST);
        }

        if (cliente.getFechaCuota() == null) {
            cliente.setFechaCuota(null);
        }

        // encriptar la contraseña antes de guardar el cliente
        cliente.setContrasena(PasswordUtil.encriptar(cliente.getContrasena()));

        Cliente clienteGuardado = clienteRepository.save(cliente);

        // enviar correo de bienvenida
        String asunto = "¡Bienvenido a World Gym Center!";
        String mensaje = """
                <html>
                <body>
                    <h2 style="color: #003366;">¡Hola, %s!</h2>
                    <p>Te damos la bienvenida a <strong>World Gym Center</strong>. Estamos encantados de tenerte con nosotros.</p>
                    <p>Esperamos que disfrutes de nuestros servicios y alcances tus objetivos de entrenamiento.</p>
                    <br>
                    <p>Si tienes alguna duda, no dudes en contactarnos.</p>
                    <p style="color: #666;">Atentamente,<br><strong>Equipo de World Gym Center</strong></p>
                </body>
                </html>
                """.formatted(clienteGuardado.getNombre());

        emailService.enviarCorreo(clienteGuardado.getEmail(), asunto, mensaje);

        return new ResponseEntity<>(Map.of("mensaje", "Cliente " + clienteGuardado.getNombre() + " con DNI " + clienteGuardado.getDni() + " se ha añadido correctamente."), HttpStatus.CREATED);
    }


    // obtener un cliente por DNI
    @GetMapping("/{dni}")
    public ResponseEntity<Cliente> obtenerCliente(@PathVariable String dni) {
        return clienteRepository.findById(dni)
                .map(cliente -> new ResponseEntity<>(cliente, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }


    @GetMapping("/dni/{email}")
    public ResponseEntity<String> obtenerDni(@PathVariable String email) {
        String dni = clienteService.obtenerDniPorEmail(email);
        if (dni != null) {
            return ResponseEntity.ok(dni);
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{dni}")
    public ResponseEntity<String> actualizarCliente(@PathVariable String dni, @RequestBody Cliente clienteActualizado) {
        // buscar al cliente por su DNI
        Cliente cliente = clienteRepository.findById(dni).orElse(null);

        if (cliente != null) {
            // variable para almacenar qué campos se han actualizado
            StringBuilder camposActualizados = new StringBuilder("Campos actualizados: ");

            boolean hayActualizacion = false;

            if (clienteActualizado.getNombre() != null && !clienteActualizado.getNombre().equals(cliente.getNombre())) {
                cliente.setNombre(clienteActualizado.getNombre());
                camposActualizados.append("Nombre, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getApellidos() != null && !clienteActualizado.getApellidos().equals(cliente.getApellidos())) {
                cliente.setApellidos(clienteActualizado.getApellidos());
                camposActualizados.append("Apellidos, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getEmail() != null && !clienteActualizado.getEmail().equals(cliente.getEmail())) {
                cliente.setEmail(clienteActualizado.getEmail());
                camposActualizados.append("Email, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getTelefono() != null && !clienteActualizado.getTelefono().equals(cliente.getTelefono())) {
                cliente.setTelefono(clienteActualizado.getTelefono());
                camposActualizados.append("Teléfono, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getContrasena() != null && !clienteActualizado.getContrasena().equals(cliente.getContrasena())) {
                cliente.setContrasena(clienteActualizado.getContrasena());
                camposActualizados.append("Contraseña, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getFechaNacimiento() != null && !clienteActualizado.getFechaNacimiento().equals(cliente.getFechaNacimiento())) {
                cliente.setFechaNacimiento(clienteActualizado.getFechaNacimiento());
                camposActualizados.append("Fecha de nacimiento, ");
                hayActualizacion = true;
            }
            if (clienteActualizado.getFechaCuota() != null && !clienteActualizado.getFechaCuota().equals(cliente.getFechaCuota())) {
                cliente.setFechaCuota(clienteActualizado.getFechaCuota());
                camposActualizados.append("Fecha de cuota, ");
                hayActualizacion = true;
            }

            // si se actualizó al menos un campo, guardamos los cambios
            if (hayActualizacion) {
                camposActualizados.setLength(camposActualizados.length() - 2); // Eliminar la última coma

                clienteRepository.save(cliente);

                return new ResponseEntity<>("Cliente con DNI " + dni + " actualizado correctamente. " + camposActualizados, HttpStatus.OK);
            }

            // si no hubo cambios en los campos, devolver 200 OK en lugar de 400
            //return new ResponseEntity<>("No se realizaron cambios para el cliente con DNI " + dni, HttpStatus.OK);
            return new ResponseEntity<>("No has realizado ningún cambio", HttpStatus.OK);
        }

        // si el cliente no se encuentra
        return new ResponseEntity<>("Cliente con DNI " + dni + " no encontrado.", HttpStatus.NOT_FOUND);
    }


    @DeleteMapping("/{dni}")
    public ResponseEntity<String> eliminarCliente(@PathVariable String dni) {
        // verificar si el cliente existe
        Optional<Cliente> clienteOpt = clienteRepository.findById(dni);

        if (clienteOpt.isPresent()) {
            Cliente cliente = clienteOpt.get();

            // enviar correo de despedida
            String asunto = "Adiós y gracias - World Gym Center";
            String mensaje = """
                    <html>
                    <body>
                        <h2 style="color: #003366;">Estimado/a %s,</h2>
                        <p>Sentimos verte partir, pero queremos agradecerte por haber sido parte de nuestra comunidad en <strong>World Gym Center</strong>.</p>
                        <p>Si en algún momento decides regresar, estaremos encantados de recibirte nuevamente.</p>
                        <br>
                        <p>¡Te deseamos lo mejor en tu camino!</p>
                        <p style="color: #666;">Atentamente,<br><strong>Equipo de World Gym Center</strong></p>
                    </body>
                    </html>
                    """.formatted(cliente.getNombre());

            emailService.enviarCorreo(cliente.getEmail(), asunto, mensaje);

            //eliminar el cliente
            clienteRepository.deleteById(dni);

            // devolver un mensaje de éxito
            String mensajeRespuesta = "Cliente con DNI " + dni + " ha sido eliminado correctamente.";
            return new ResponseEntity<>(mensajeRespuesta, HttpStatus.OK);
        }

        // si no se encuentra el cliente
        String mensajeError = "Cliente con DNI " + dni + " no encontrado.";
        return new ResponseEntity<>(mensajeError, HttpStatus.NOT_FOUND);
    }


    // obtener clientes ordenados por nombre o apellidos
    @GetMapping("/ordenados")
    public List<Cliente> obtenerClientesOrdenados(
            @RequestParam(required = false) String campo, // campo por el que se ordena (nombre/apellidos/fechaCuota)
            @RequestParam(required = false, defaultValue = "asc") String orden // orden ascendente o descendente
    ) {
        if ("apellidos".equalsIgnoreCase(campo)) {
            return "desc".equalsIgnoreCase(orden) ?
                    clienteRepository.findAllByOrderByApellidosDesc() :
                    clienteRepository.findAllByOrderByApellidosAsc();
        } else if ("fechaCuota".equalsIgnoreCase(campo)) {
            return "desc".equalsIgnoreCase(orden) ?
                    clienteRepository.findAllByOrderByFechaCuotaDesc() :
                    clienteRepository.findAllByOrderByFechaCuotaAsc();
        } else {
            // Por defecto, ordena por nombre
            return "desc".equalsIgnoreCase(orden) ?
                    clienteRepository.findAllByOrderByNombreDesc() :
                    clienteRepository.findAllByOrderByNombreAsc();
        }
    }

    @GetMapping("/cuotas-atrasadas")
    public List<Cliente> obtenerClientesConCuotasAtrasadas(
            @RequestParam(defaultValue = "asc") String orden
    ) {
        // fecha actual para filtrar cuotas atrasadas
        LocalDate fechaActual = LocalDate.now();

        // ordenar por fecha de cuota
        return "desc".equalsIgnoreCase(orden) ?
                clienteRepository.findByFechaCuotaBefore(fechaActual).stream()
                        .sorted((c1, c2) -> c2.getFechaCuota().compareTo(c1.getFechaCuota()))
                        .toList() :
                clienteRepository.findByFechaCuotaBefore(fechaActual).stream()
                        .sorted((c1, c2) -> c1.getFechaCuota().compareTo(c2.getFechaCuota()))
                        .toList();
    }


    @GetMapping("/cuotas-proximas/{dias}")
    public ResponseEntity<List<Cliente>> obtenerClientesCuotasProximas(@PathVariable int dias) {
        if (dias <= 0) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        // Calcular el rango de fechas
        LocalDate hoy = LocalDate.now();
        LocalDate fechaFin = hoy.plusDays(dias);

        // Obtener clientes en el rango buscado
        List<Cliente> clientes = clienteRepository.findByFechaCuotaBetween(hoy, fechaFin);

        if (clientes.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Sin resultados
        }

        return new ResponseEntity<>(clientes, HttpStatus.OK); // Resultado exitoso
    }

    //  cambios de contraseña
    @PostMapping("/cambiar-contrasena/{dni}/{contrasenaActual}/{nuevaContrasena}")
    public ResponseEntity<String> cambiarContrasena(
            @PathVariable String dni,
            @PathVariable String contrasenaActual,
            @PathVariable String nuevaContrasena) {

        boolean cambiado = clienteService.cambiarContrasenaAutenticado(dni, contrasenaActual, nuevaContrasena);

        if (cambiado) {
            return ResponseEntity.ok("Contraseña cambiada correctamente.");
        } else {
            return ResponseEntity.badRequest().body("Error: contraseña incorrecta.");
        }
    }


    //contraseña olvidada, se pide dni e email
    @PostMapping("/recuperar-contrasena/{dni}/{email}")
    public ResponseEntity<String> recuperarContrasena(
            @PathVariable String dni,
            @PathVariable String email) {

        boolean recuperado = clienteService.recuperarContrasena(dni, email);

        if (recuperado) {
            return ResponseEntity.ok("Hemos enviado un correo con tu nueva contraseña.\nTe sugerimos iniciar sesión y cambiarla por una más segura lo antes posible.");
        } else {
            return ResponseEntity.badRequest().body("Error: DNI o email incorrecto.");
        }
    }


    @PostMapping("/login/{email}/{contrasena}")
    public ResponseEntity<String> login(
            @PathVariable String email,
            @PathVariable String contrasena) {

        Cliente cliente = clienteService.obtenerClientePorEmailYContrasena(email, contrasena);

        if (cliente != null) {
            return ResponseEntity.ok(cliente.getDni()); // Devuelve el DNI si las credenciales son correctas
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Error: Email o contraseña incorrectos.");
        }
    }


}
