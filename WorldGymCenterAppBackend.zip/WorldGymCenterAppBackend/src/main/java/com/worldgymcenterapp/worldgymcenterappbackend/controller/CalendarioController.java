// controlador REST para gestionar los eventos del calendario
package com.worldgymcenterapp.worldgymcenterappbackend.controller;

import com.worldgymcenterapp.worldgymcenterappbackend.model.Calendario;
import com.worldgymcenterapp.worldgymcenterappbackend.service.CalendarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

// anotación para definir el controlador como un servicio REST
@RestController
@RequestMapping("/calendario") // ruta base para los endpoints relacionados con el calendario
public class CalendarioController {

    @Autowired
    private CalendarioService calendarioService; // inyección del servicio que maneja la lógica de negocio del calendario

    // obtiene todos los eventos del calendario
    @GetMapping
    public List<Calendario> getAllCalendarios() {
        return calendarioService.getAllCalendarios(); // llama al servicio para obtener todos los calendarios
    }

    // obtiene un evento específico por su id
    @GetMapping("/{id}")
    public ResponseEntity<Calendario> getCalendarioById(@PathVariable Long id) {
        Optional<Calendario> calendario = calendarioService.getCalendarioById(id); // busca el calendario por id
        return calendario.map(ResponseEntity::ok) // si el evento existe, lo devuelve con status 200
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build()); // si no existe, devuelve status 404
    }

    // crea un nuevo evento en el calendario
    @PostMapping
    public ResponseEntity<Calendario> createCalendario(@RequestBody Calendario calendario) {
        Calendario createdCalendario = calendarioService.createCalendario(calendario); // llama al servicio para crear el evento
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCalendario); // devuelve el evento creado con status 201
    }

    // actualiza un evento existente por su id
    @PutMapping("/{id}")
    public ResponseEntity<Calendario> updateCalendario(@PathVariable Long id, @RequestBody Calendario calendarioDetails) {
        Calendario updatedCalendario = calendarioService.updateCalendario(id, calendarioDetails); // actualiza el evento
        return ResponseEntity.ok(updatedCalendario); // devuelve el evento actualizado con status 200
    }

    // elimina un evento del calendario por su id
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCalendario(@PathVariable Long id) {
        calendarioService.deleteCalendario(id); // llama al servicio para eliminar el evento
        return ResponseEntity.noContent().build(); // devuelve status 204 si la eliminación fue exitosa
    }

    // obtiene eventos en una fecha específica
    @GetMapping("/eventosPorFecha")
    public ResponseEntity<List<Calendario>> getEventosPorFecha(@RequestParam("fecha") String fecha) {
        try {
            fecha = fecha.trim(); // elimina espacios o saltos de línea alrededor de la fecha
            LocalDate fechaConsulta = LocalDate.parse(fecha); // convierte la fecha de string a LocalDate
            List<Calendario> eventos = calendarioService.getEventosByFecha(fechaConsulta); // obtiene los eventos para esa fecha
            return ResponseEntity.ok(eventos); // devuelve la lista de eventos con status 200
        } catch (Exception e) {
            System.err.println("Error al parsear la fecha: " + e.getMessage()); // muestra error en la consola
            return ResponseEntity.badRequest().body(null); // devuelve status 400 si la fecha no es válida
        }
    }

    // obtiene eventos en un rango de fechas
    @GetMapping("/eventosPorRango")
    public ResponseEntity<List<Calendario>> getEventosPorRango(@RequestParam("start") String start, @RequestParam("end") String end) {
        LocalDateTime startDate = LocalDateTime.parse(start); // convierte las fechas de parámetros a LocalDateTime
        LocalDateTime endDate = LocalDateTime.parse(end);
        List<Calendario> eventos = calendarioService.getEventosByFechaRango(startDate, endDate); // obtiene eventos en el rango
        return ResponseEntity.ok(eventos); // devuelve la lista de eventos con status 200
    }

    // agrega un nuevo evento al calendario
    @PostMapping("/agregarEvento")
    public ResponseEntity<Calendario> agregarEvento(@RequestBody Calendario calendario) {
        try {
            Calendario eventoGuardado = calendarioService.createCalendario(calendario); // guarda el evento en la base de datos
            return ResponseEntity.status(HttpStatus.CREATED).body(eventoGuardado); // devuelve el evento creado con status 201
        } catch (Exception e) {
            e.printStackTrace(); // maneja el error y muestra en consola
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // devuelve status 400 en caso de error
        }
    }

    // elimina un evento por su id
    @DeleteMapping("eliminarEvento/{id}")
    public ResponseEntity<String> eliminarEvento(@PathVariable Long id) {
        boolean isDeleted = calendarioService.eliminarEvento(id); // llama al servicio para eliminar el evento
        if (isDeleted) {
            return ResponseEntity.ok("Evento eliminado con éxito"); // evento eliminado exitosamente
        } else {
            return ResponseEntity.status(404).body("Evento no encontrado con id " + id); // evento no encontrado
        }
    }

    // actualiza un evento existente
    @PutMapping("/actualizarEvento/{id}")
    public ResponseEntity<String> actualizarEvento(@PathVariable Long id, @RequestBody Calendario calendarioDetails) {
        Calendario updatedCalendario = calendarioService.actualizarEvento(id, calendarioDetails); // actualiza el evento
        if (updatedCalendario != null) {
            return ResponseEntity.ok("Evento actualizado con éxito"); // evento actualizado exitosamente
        } else {
            return ResponseEntity.status(404).body("Evento no encontrado con id " + id); // evento no encontrado
        }
    }

}
