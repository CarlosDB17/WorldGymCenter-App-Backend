// servicio para el envio de correos electronicos utilizando JavaMailSender
package com.worldgymcenterapp.worldgymcenterappbackend.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

// la anotacion @Service indica que esta clase es un servicio de Spring que puede ser inyectado en otros componentes
@Service
public class EmailService {

    // inyeccion de dependencia del JavaMailSender para enviar correos electronicos
    @Autowired
    private JavaMailSender mailSender;

    // metodo para enviar un correo electronico con el destinatario, asunto y mensaje especificados
    public void enviarCorreo(String destinatario, String asunto, String mensaje) {
        try {
            // crear un objeto MimeMessage para representar el correo electronico
            MimeMessage mail = mailSender.createMimeMessage();
            // usar MimeMessageHelper para configurar el correo (con soporte para HTML)
            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
            helper.setTo(destinatario);  // establecer destinatario del correo
            helper.setSubject(asunto);   // establecer el asunto del correo
            helper.setText(mensaje, true); // establecer el mensaje del correo (true indica que el mensaje es HTML)
            // enviar el correo a traves de mailSender
            mailSender.send(mail);
        } catch (MessagingException e) {
            // capturar posibles excepciones al enviar el correo y lanzar una excepcion de runtime
            throw new RuntimeException("Error al enviar el correo: " + e.getMessage());
        }
    }
}
