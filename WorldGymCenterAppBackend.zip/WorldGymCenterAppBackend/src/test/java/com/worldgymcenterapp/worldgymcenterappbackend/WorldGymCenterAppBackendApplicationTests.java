package com.worldgymcenterapp.worldgymcenterappbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorldGymCenterAppBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
